# 中央競馬分析ダッシュボード iPhone Cloud版

## iPhoneから公開
1. GitHubで新規リポジトリ `keiba-analysis` を作成（Public）。
2. リポジトリの `Add file` → `Upload files` で、ZIPを展開した中の `app.py`, `engine.py`, `requirements.txt` をリポジトリ直下へアップロード。サンプルの `entries.csv`, `history.csv` もアップロード可能です（架空データ）。
3. https://share.streamlit.io でGitHub連携し `Create app` を選択。
4. Repository: `<username>/keiba-analysis`, Branch: `main`, Main file path: `app.py` でDeploy。
5. 発行されたURLをiPhoneのSafariで開き、CSV 2つをアップロードして「CSVを読み込んで分析」を押す。

## 注意
- CSVはUTF-8、列名は同梱サンプル参照。
- クラウド版ではセッションごとにCSVを読み込み、SQLiteへは保存しません。ページ再接続時には再アップロードが必要です。
- サンプルは架空データ。スコアは勝率ではありません。
- 実際の個人データや権利制限のあるCSVを公開リポジトリに置かないでください。
